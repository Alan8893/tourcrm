# TourCRM Visual Assets v1.0 — FINAL

Approved Navigation asset package.

## Navigation
- home
- people
- groups
- events
- achievements
- reports
- settings

## Settings
The Settings icon uses the approved compass concept with a wrench replacing the compass needle.

## Production format
WebP raster only.
Sizes: 16 / 20 / 24 / 32 / 48 / 64 px.
PNG masters are included as high-resolution raster sources.

## Visual direction
Light, friendly TourCRM UI; outdoor/sticker illustration language; bold dark outlines; vivid but balanced travel palette; individual tourism metaphors; readable at small UI sizes.

## Important
No SVG files are included.
No generic icon-library assets are included.
